$(document).ready(function () {
    

    $('#sb').click(function () {

        var uname = $('#un').val();
        var pwd = $('#pd').val();

        if (uname == '' || pwd == '') {

            alert("Pls enter valid data");
            
        }
       
        });
        
        });