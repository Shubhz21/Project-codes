$(document).ready(function () {
    

    $('#sub').click(function () {

        var box = $('#box').val();
        

        if (box == '') {

            alert("Pls enter valid name");
            
        }
        });
        
        });