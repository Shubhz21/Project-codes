package com.shubham;

//import java.io.IOException;
//
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Registration extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		
		String username = request.getParameter("uname");
		String password = request.getParameter("pd");
		
		PrintWriter pw = response.getWriter();
//		out.println(username+"   "+password);
		//pw.println("<h1>We got your data.. Registration was Successfull!!!</h1>");
		
		Connection con;
		PreparedStatement stmt;
		ResultSet rs;
		
		try
		{
			Class.forName("org.postgresql.Driver");
			
			con = DriverManager.getConnection("jdbc:postgresql://localhost/userdata","data","data");
			stmt = con.prepareStatement("insert into credentials values(?,?);");
			stmt.setString(1, username);
			stmt.setString(2, password);
			
			int x = stmt.executeUpdate();
			con.close();
			pw.println("<center><h2>We got your data.. Registration was Successfull!!!</h2></center>");
		}
		catch(Exception e)
		{
			pw.println("<center><h2>Already u have Registered</h2></center>");
			e.printStackTrace();
		}
		
	}

}
